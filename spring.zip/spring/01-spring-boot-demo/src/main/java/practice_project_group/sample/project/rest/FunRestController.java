package practice_project_group.sample.project.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class FunRestController {
//exposr "/" that return helloworld
@GetMapping("/")
    public String SayHello()
    {
        return "Hello World !";
    }
}
