package practice_project_group.sample.project.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class FunRestController {
//exposr "/" that return helloworld
@GetMapping("/")
    public String SayHello()
    {
        return "Hello World !";
    }

@GetMapping("/workout")
    public String DailyWorkOut()
    {
        return "Run hard 5k!";
    }
@GetMapping("/fortune")
    public String YourFortune()
    {
        return "This is your lucky day!!";
    }
}