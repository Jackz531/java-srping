package com.jackson.springbootdemo;

import org.springframework.stereotype.Component;

@Component
public class Laptop {
    public void compile()
    {
        System.out.println("compile....");
    }
}
