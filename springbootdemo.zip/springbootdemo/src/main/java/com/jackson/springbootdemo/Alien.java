package com.jackson.springbootdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component//annotation instructing spring to create the object

public class Alien {
    @Autowired//spring knows that alien is depenpdent on laptop object
Laptop laptop;
    public void code(){

        laptop.compile();
    }

}
